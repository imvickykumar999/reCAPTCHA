# forms.py 

from django import forms 
from django_recaptcha.fields import ReCaptchaField
from django_recaptcha.widgets import ReCaptchaV2Checkbox 


class ContactForm(forms.Form): 
	email = forms.EmailField() 
	feedback = forms.CharField(widget=forms.Textarea) 
	captcha = ReCaptchaField(widget=ReCaptchaV2Checkbox) 

